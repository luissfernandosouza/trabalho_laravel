<!DOCTYPE html>
<html><h1>Lista de Filmes Favoritos</h1></html>
<?php

foreach ($filmes as $filme) {
   echo $filme . "<br>";
}



?>


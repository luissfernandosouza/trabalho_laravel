<h1>Laravel</h1>
<a href="/filmes">voltar</a>
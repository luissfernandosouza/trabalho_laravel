<h1>Laravel</h1>
<?php /**PATH C:\xampp\htdocs\trabalho_laravel\resources\views/home.blade.php ENDPATH**/ ?>